# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   Authors :       sundapeng.sdp
   Date：          2023/3/22
   Description :
-------------------------------------------------
"""
__author__ = 'sundapeng.sdp'

from .wfuzz import WfuzzFactory
from .interface import AbstractFactory